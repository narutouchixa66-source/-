package com.java.notchtouch

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity

class FakeBootActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var screenBlack = false

    private val VOLUME_NEEDED = 10
    private val VOLUME_WINDOW_MS = 2000L
    private var volCount = 0
    private var lastVolTime = 0L
    private val volResetRunnable = Runnable { volCount = 0 }

    private lateinit var rootView: FrameLayout
    private lateinit var contentLayout: LinearLayout
    private lateinit var blackOverlay: View

    // flicker: the whole content goes black for ~80ms then comes back
    private val flickerRunnable = object : Runnable {
        override fun run() {
            screenBlack = true
            blackOverlay.visibility = View.VISIBLE
            handler.postDelayed({
                blackOverlay.visibility = View.GONE
                screenBlack = false
            }, 80)
            handler.postDelayed(this, 2500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        buildUI()
        handler.postDelayed(flickerRunnable, 2500)
    }

    private fun buildUI() {
        rootView = FrameLayout(this)
        rootView.setBackgroundColor(Color.BLACK)

        // ---- centered content: Mi logo + small spacing ----
        contentLayout = LinearLayout(this)
        contentLayout.orientation = LinearLayout.VERTICAL
        contentLayout.gravity = Gravity.CENTER

        val logoView = buildMiLogo()
        contentLayout.addView(logoView)

        val contentLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        contentLp.gravity = Gravity.CENTER
        rootView.addView(contentLayout, contentLp)

        // ---- "Powered by android" at the very bottom center ----
        val bottomLayout = LinearLayout(this)
        bottomLayout.orientation = LinearLayout.VERTICAL
        bottomLayout.gravity = Gravity.CENTER_HORIZONTAL
        bottomLayout.setPadding(0, 0, 0, dp(32))

        val poweredBy = TextView(this)
        poweredBy.text = "Powered by"
        poweredBy.setTextColor(Color.WHITE)
        poweredBy.textSize = 12f
        poweredBy.gravity = Gravity.CENTER
        poweredBy.alpha = 0.85f
        bottomLayout.addView(poweredBy)

        val androidText = TextView(this)
        androidText.text = "android"
        androidText.setTextColor(Color.WHITE)
        androidText.textSize = 22f
        androidText.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        androidText.gravity = Gravity.CENTER
        androidText.alpha = 0.90f
        bottomLayout.addView(androidText)

        val bottomLp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        bottomLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        rootView.addView(bottomLayout, bottomLp)

        // ---- black flicker overlay (on top of everything) ----
        blackOverlay = View(this)
        blackOverlay.setBackgroundColor(Color.BLACK)
        blackOverlay.visibility = View.GONE
        rootView.addView(blackOverlay, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        setContentView(rootView)
    }

    private fun buildMiLogo(): View {
        // White rounded-square card containing the "MI" lettermark
        val size = dp(100)
        val card = androidx.cardview.widget.CardView(this)
        card.radius = dp(22).toFloat()
        card.setCardBackgroundColor(Color.WHITE)
        card.cardElevation = 0f
        val cardLp = LinearLayout.LayoutParams(size, size)
        card.layoutParams = cardLp

        val miText = TextView(this)
        miText.text = "MI"
        miText.setTextColor(Color.BLACK)
        miText.textSize = 34f
        miText.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        miText.gravity = Gravity.CENTER
        card.addView(miText, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ))

        return card
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { /* blocked */ }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean = true

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            val now = System.currentTimeMillis()
            if (now - lastVolTime > VOLUME_WINDOW_MS) volCount = 0
            lastVolTime = now
            volCount++
            handler.removeCallbacks(volResetRunnable)
            handler.postDelayed(volResetRunnable, VOLUME_WINDOW_MS)
            vibrate(10)
            if (volCount >= VOLUME_NEEDED) unlock()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            volCount = 0
            return true
        }
        return true // block everything else
    }

    private fun unlock() {
        handler.removeCallbacksAndMessages(null)
        finish()
    }

    private fun vibrate(ms: Long) {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) { }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
