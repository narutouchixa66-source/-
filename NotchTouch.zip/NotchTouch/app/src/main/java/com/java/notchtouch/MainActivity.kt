package com.java.notchtouch

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.MotionEvent
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val gestureLabels = mapOf(
        NotchGesture.SINGLE_TAP to "Одиночный тап",
        NotchGesture.DOUBLE_TAP to "Двойной тап",
        NotchGesture.LONG_PRESS to "Долгое нажатие",
        NotchGesture.SWIPE_LEFT to "Свайп влево",
        NotchGesture.SWIPE_RIGHT to "Свайп вправо"
    )

    private val actionLabels = mapOf(
        NotchAction.NONE to "Ничего",
        NotchAction.SCREENSHOT to "Скриншот",
        NotchAction.TORCH_TOGGLE to "Фонарик",
        NotchAction.LOCK_SCREEN to "Блокировка экрана",
        NotchAction.HOME to "Домой",
        NotchAction.RECENTS to "Последние приложения",
        NotchAction.NOTIFICATIONS to "Шторка уведомлений",
        NotchAction.BACK to "Назад",
        NotchAction.OPEN_APP to "Открыть приложение"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.Button>(R.id.btnEnableService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        setupGestureSpinners()
        setupSizeControls()
        setupAppSpinner()
        setupPositionPreview()
    }

    override fun onResume() {
        super.onResume()
        val status = findViewById<TextView>(R.id.tvServiceStatus)
        status.text = if (isAccessibilityServiceEnabled())
            "Служба активна ✅" else "Служба не включена — нажми кнопку ниже"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, NotchAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun setupGestureSpinners() {
        val actions = NotchAction.values().toList()
        val actionNames = actions.map { actionLabels[it] ?: it.name }

        val spinnerIds = mapOf(
            NotchGesture.SINGLE_TAP to R.id.spinnerSingleTap,
            NotchGesture.DOUBLE_TAP to R.id.spinnerDoubleTap,
            NotchGesture.LONG_PRESS to R.id.spinnerLongPress,
            NotchGesture.SWIPE_LEFT to R.id.spinnerSwipeLeft,
            NotchGesture.SWIPE_RIGHT to R.id.spinnerSwipeRight
        )

        for ((gesture, viewId) in spinnerIds) {
            val spinner = findViewById<Spinner>(viewId)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, actionNames)
            val current = GesturePrefs.getAction(this, gesture)
            spinner.setSelection(actions.indexOf(current))
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    GesturePrefs.setAction(this@MainActivity, gesture, actions[pos])
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
        }
    }

    private fun setupSizeControls() {
        val seekWidth = findViewById<SeekBar>(R.id.seekWidth)
        val seekHeight = findViewById<SeekBar>(R.id.seekHeight)

        seekWidth.progress = GesturePrefs.getWidthDp(this)
        seekHeight.progress = GesturePrefs.getHeightDp(this)

        seekWidth.setOnSeekBarChangeListener(simpleSeek {
            GesturePrefs.setWidthDp(this, it.coerceAtLeast(40))
            if (::previewZone.isInitialized) resizePreviewZone()
        })
        seekHeight.setOnSeekBarChangeListener(simpleSeek {
            GesturePrefs.setHeightDp(this, it.coerceAtLeast(16))
            if (::previewZone.isInitialized) resizePreviewZone()
        })
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun setupAppSpinner() {
        val spinner = findViewById<Spinner>(R.id.spinnerOpenApp)
        val pm = packageManager
        val launchable = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { it.loadLabel(pm).toString() }

        val labels = launchable.map { it.loadLabel(pm).toString() }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        val savedPkg = GesturePrefs.getOpenAppPackage(this)
        val savedIndex = launchable.indexOfFirst { it.packageName == savedPkg }
        if (savedIndex >= 0) spinner.setSelection(savedIndex)

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                GesturePrefs.setOpenAppPackage(this@MainActivity, launchable[pos].packageName)
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
    }

    // ---------------- draggable position preview ----------------
    // The preview frame stands in for the real screen. Dragging the orange
    // box inside it sets a relative position (0..1 on each axis), which gets
    // converted to real device dp and saved — that's what the invisible
    // overlay actually uses at runtime. The preview frame is resized to match
    // the real screen's aspect ratio, and the box inside it live-resizes as
    // you move the width/height sliders — so what you see is proportionally
    // accurate to your actual phone.
    private lateinit var previewFrame: FrameLayout
    private lateinit var previewZone: android.view.View
    private var previewScale = 1f // px in preview per real px on device

    private fun setupPositionPreview() {
        previewFrame = findViewById(R.id.previewFrame)
        previewZone = findViewById(R.id.previewZone)

        previewFrame.post {
            val screenWPx = resources.displayMetrics.widthPixels
            val screenHPx = resources.displayMetrics.heightPixels
            val frameW = previewFrame.width

            // resize the preview frame's height to match the device's real aspect ratio
            val frameH = (frameW.toFloat() * screenHPx / screenWPx).roundToInt()
            val lp = previewFrame.layoutParams
            lp.height = frameH
            previewFrame.layoutParams = lp

            previewScale = frameW.toFloat() / screenWPx

            previewFrame.post {
                resizePreviewZone()
                placePreviewZoneFromPrefs()
            }
        }

        previewZone.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragDownRawX = ev.rawX
                    dragDownRawY = ev.rawY
                    dragStartLeft = (v.layoutParams as FrameLayout.LayoutParams).leftMargin
                    dragStartTop = (v.layoutParams as FrameLayout.LayoutParams).topMargin
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - dragDownRawX).roundToInt()
                    val dy = (ev.rawY - dragDownRawY).roundToInt()
                    val maxLeft = (previewFrame.width - v.width).coerceAtLeast(0)
                    val maxTop = (previewFrame.height - v.height).coerceAtLeast(0)
                    val newLeft = (dragStartLeft + dx).coerceIn(0, maxLeft)
                    val newTop = (dragStartTop + dy).coerceIn(0, maxTop)
                    moveZoneTo(v, newLeft, newTop)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val zoneLp = v.layoutParams as FrameLayout.LayoutParams
                    savePositionFromPreview(zoneLp.leftMargin, zoneLp.topMargin)
                    true
                }
                else -> false
            }
        }
    }

    private var dragDownRawX = 0f
    private var dragDownRawY = 0f
    private var dragStartLeft = 0
    private var dragStartTop = 0

    /** Resizes the visible preview box to match the current width/height sliders, scaled to the preview. */
    private fun resizePreviewZone() {
        val realWidthPx = dpToPx(GesturePrefs.getWidthDp(this))
        val realHeightPx = dpToPx(GesturePrefs.getHeightDp(this))
        val lp = previewZone.layoutParams as FrameLayout.LayoutParams
        val oldW = lp.width; val oldH = lp.height
        lp.width = (realWidthPx * previewScale).roundToInt().coerceAtLeast(8)
        lp.height = (realHeightPx * previewScale).roundToInt().coerceAtLeast(8)

        // keep it within bounds after a resize (in case it now overflows the frame)
        val maxLeft = (previewFrame.width - lp.width).coerceAtLeast(0)
        val maxTop = (previewFrame.height - lp.height).coerceAtLeast(0)
        lp.leftMargin = lp.leftMargin.coerceIn(0, maxLeft)
        lp.topMargin = lp.topMargin.coerceIn(0, maxTop)

        previewZone.layoutParams = lp
        if (oldW != lp.width || oldH != lp.height) {
            savePositionFromPreview(lp.leftMargin, lp.topMargin)
        }
    }

    private fun placePreviewZoneFromPrefs() {
        val frameW = previewFrame.width
        val frameH = previewFrame.height
        val zoneW = previewZone.width
        val zoneH = previewZone.height

        val (fracX, fracY) = if (GesturePrefs.isPositionSet(this)) {
            val screenWDp = pxToDp(resources.displayMetrics.widthPixels)
            val screenHDp = pxToDp(resources.displayMetrics.heightPixels)
            val xDp = GesturePrefs.getOffsetXDp(this)
            val yDp = GesturePrefs.getOffsetYDp(this)
            (xDp.toFloat() / screenWDp).coerceIn(0f, 1f) to (yDp.toFloat() / screenHDp).coerceIn(0f, 1f)
        } else {
            0.5f to 0.05f // default: top-center, like a real notch
        }

        val left = (fracX * (frameW - zoneW)).roundToInt()
        val top = (fracY * (frameH - zoneH)).roundToInt()
        moveZoneTo(previewZone, left, top)
    }

    private fun moveZoneTo(zone: android.view.View, left: Int, top: Int) {
        val lp = zone.layoutParams as FrameLayout.LayoutParams
        lp.leftMargin = left
        lp.topMargin = top
        zone.layoutParams = lp
    }

    private fun savePositionFromPreview(left: Int, top: Int) {
        val frameW = previewFrame.width - previewZone.width
        val frameH = previewFrame.height - previewZone.height
        val fracX = if (frameW > 0) left.toFloat() / frameW else 0f
        val fracY = if (frameH > 0) top.toFloat() / frameH else 0f

        val screenWDp = pxToDp(resources.displayMetrics.widthPixels)
        val screenHDp = pxToDp(resources.displayMetrics.heightPixels)
        val xDp = (fracX * screenWDp).roundToInt()
        val yDp = (fracY * screenHDp).roundToInt()

        GesturePrefs.setPosition(this, xDp, yDp)
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).roundToInt()

    private fun pxToDp(px: Int): Int =
        (px / resources.displayMetrics.density).roundToInt()
}
