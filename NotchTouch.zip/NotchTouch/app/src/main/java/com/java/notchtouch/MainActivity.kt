package com.java.notchtouch

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val gestureLabels = mapOf(
        NotchGesture.SINGLE_TAP to "Одиночный тап",
        NotchGesture.DOUBLE_TAP to "Двойной тап",
        NotchGesture.LONG_PRESS to "Долгое нажатие",
        NotchGesture.SWIPE_LEFT to "Свайп влево",
        NotchGesture.SWIPE_RIGHT to "Свайп вправо"
    )

    private val actionLabels = mapOf(
        NotchAction.NONE to "Ничего",
        NotchAction.SCREENSHOT to "Скриншот",
        NotchAction.TORCH_TOGGLE to "Фонарик",
        NotchAction.LOCK_SCREEN to "Блокировка экрана",
        NotchAction.HOME to "Домой",
        NotchAction.RECENTS to "Последние приложения",
        NotchAction.NOTIFICATIONS to "Шторка уведомлений",
        NotchAction.BACK to "Назад",
        NotchAction.OPEN_APP to "Открыть приложение"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.Button>(R.id.btnEnableService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        setupGestureSpinners()
        setupSizeControls()
        setupAppSpinner()
    }

    override fun onResume() {
        super.onResume()
        val status = findViewById<TextView>(R.id.tvServiceStatus)
        status.text = if (isAccessibilityServiceEnabled())
            "Служба активна ✅" else "Служба не включена — нажми кнопку ниже"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expected = ComponentName(this, NotchAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabled)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expected, ignoreCase = true)) return true
        }
        return false
    }

    private fun setupGestureSpinners() {
        val actions = NotchAction.values().toList()
        val actionNames = actions.map { actionLabels[it] ?: it.name }

        val spinnerIds = mapOf(
            NotchGesture.SINGLE_TAP to R.id.spinnerSingleTap,
            NotchGesture.DOUBLE_TAP to R.id.spinnerDoubleTap,
            NotchGesture.LONG_PRESS to R.id.spinnerLongPress,
            NotchGesture.SWIPE_LEFT to R.id.spinnerSwipeLeft,
            NotchGesture.SWIPE_RIGHT to R.id.spinnerSwipeRight
        )

        for ((gesture, viewId) in spinnerIds) {
            val spinner = findViewById<Spinner>(viewId)
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, actionNames)
            val current = GesturePrefs.getAction(this, gesture)
            spinner.setSelection(actions.indexOf(current))
            spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    GesturePrefs.setAction(this@MainActivity, gesture, actions[pos])
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
        }
    }

    private fun setupSizeControls() {
        val seekWidth = findViewById<SeekBar>(R.id.seekWidth)
        val seekHeight = findViewById<SeekBar>(R.id.seekHeight)
        val seekOffset = findViewById<SeekBar>(R.id.seekOffset)

        seekWidth.progress = GesturePrefs.getWidthDp(this)
        seekHeight.progress = GesturePrefs.getHeightDp(this)
        seekOffset.progress = GesturePrefs.getOffsetYDp(this)

        seekWidth.setOnSeekBarChangeListener(simpleSeek { GesturePrefs.setWidthDp(this, it.coerceAtLeast(40)) })
        seekHeight.setOnSeekBarChangeListener(simpleSeek { GesturePrefs.setHeightDp(this, it.coerceAtLeast(16)) })
        seekOffset.setOnSeekBarChangeListener(simpleSeek { GesturePrefs.setOffsetYDp(this, it) })
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun setupAppSpinner() {
        val spinner = findViewById<Spinner>(R.id.spinnerOpenApp)
        val pm = packageManager
        val launchable = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { it.loadLabel(pm).toString() }

        val labels = launchable.map { it.loadLabel(pm).toString() }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        val savedPkg = GesturePrefs.getOpenAppPackage(this)
        val savedIndex = launchable.indexOfFirst { it.packageName == savedPkg }
        if (savedIndex >= 0) spinner.setSelection(savedIndex)

        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                GesturePrefs.setOpenAppPackage(this@MainActivity, launchable[pos].packageName)
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }
    }
}
