package com.java.notchtouch

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

class NotchAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private lateinit var gestureDetector: GestureDetector
    private var torchOn = false
    private var cameraId: String? = null

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key?.startsWith("overlay_") == true) {
            updateOverlayGeometry()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupTorch()
        setupGestureDetector()
        addOverlay()
        GesturePrefs.prefs(this).registerOnSharedPreferenceChangeListener(prefsListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }
    override fun onInterrupt() { /* not used */ }

    override fun onDestroy() {
        super.onDestroy()
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        GesturePrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(prefsListener)
    }

    // ---------- Overlay ----------

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()

    private fun addOverlay() {
        if (!GesturePrefs.isEnabled(this)) return

        val view = View(this)
        view.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }

        val params = WindowManager.LayoutParams(
            dpToPx(GesturePrefs.getWidthDp(this)),
            dpToPx(GesturePrefs.getHeightDp(this)),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        applyPosition(params)

        runCatching { windowManager.addView(view, params) }
        overlayView = view
    }

    /** Uses the saved absolute position, or centers near the top (like a real notch) if never set. */
    private fun applyPosition(params: WindowManager.LayoutParams) {
        if (GesturePrefs.isPositionSet(this)) {
            params.x = dpToPx(GesturePrefs.getOffsetXDp(this))
            params.y = dpToPx(GesturePrefs.getOffsetYDp(this))
        } else {
            val screenWidthPx = resources.displayMetrics.widthPixels
            params.x = (screenWidthPx - params.width) / 2
            params.y = dpToPx(24)
        }
    }

    private fun updateOverlayGeometry() {
        val view = overlayView ?: return
        val params = view.layoutParams as? WindowManager.LayoutParams ?: return
        params.width = dpToPx(GesturePrefs.getWidthDp(this))
        params.height = dpToPx(GesturePrefs.getHeightDp(this))
        applyPosition(params)
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    // ---------- Gestures ----------

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                trigger(NotchGesture.SINGLE_TAP)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                trigger(NotchGesture.DOUBLE_TAP)
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                trigger(NotchGesture.LONG_PRESS)
            }

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                if (abs(dx) < 40) return false
                if (dx > 0) trigger(NotchGesture.SWIPE_RIGHT) else trigger(NotchGesture.SWIPE_LEFT)
                return true
            }
        })
    }

    private fun trigger(gesture: NotchGesture) {
        vibrate()
        when (GesturePrefs.getAction(this, gesture)) {
            NotchAction.SCREENSHOT -> performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            NotchAction.LOCK_SCREEN -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            NotchAction.HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            NotchAction.RECENTS -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            NotchAction.NOTIFICATIONS -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            NotchAction.BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            NotchAction.TORCH_TOGGLE -> toggleTorch()
            NotchAction.OPEN_APP -> openConfiguredApp()
            NotchAction.NONE -> { /* do nothing */ }
        }
    }

    private fun vibrate() {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(25)
            }
        } catch (e: Exception) {
            // never let a missing vibrator permission/service crash the service
        }
    }

    // ---------- Torch ----------

    private fun setupTorch() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraId = cameraManager.cameraIdList.firstOrNull { id ->
            cameraManager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }

    private fun toggleTorch() {
        val id = cameraId ?: return
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        torchOn = !torchOn
        runCatching { cameraManager.setTorchMode(id, torchOn) }
    }

    // ---------- Open app ----------

    private fun openConfiguredApp() {
        val pkg = GesturePrefs.getOpenAppPackage(this) ?: return
        val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }
}
