package com.java.notchtouch

import android.content.Context
import android.content.SharedPreferences

/** Actions the notch button can trigger. */
enum class NotchAction {
    NONE,
    SCREENSHOT,
    TORCH_TOGGLE,
    LOCK_SCREEN,
    HOME,
    RECENTS,
    NOTIFICATIONS,
    BACK,
    OPEN_APP,
    FAKE_BOOT
}

/** Gestures recognized on the notch touch region. */
enum class NotchGesture {
    SINGLE_TAP,
    DOUBLE_TAP,
    LONG_PRESS,
    SWIPE_LEFT,
    SWIPE_RIGHT
}

object GesturePrefs {
    private const val PREFS_NAME = "notch_touch_prefs"

    private const val KEY_WIDTH = "overlay_width_dp"
    private const val KEY_HEIGHT = "overlay_height_dp"
    private const val KEY_OFFSET_X = "overlay_offset_x_dp"
    private const val KEY_OFFSET_Y = "overlay_offset_y_dp"
    private const val KEY_POSITION_SET = "overlay_position_set" // false until first drag/centering
    private const val KEY_EDIT_MODE = "overlay_edit_mode"
    private const val KEY_APP_PACKAGE = "open_app_package"
    private const val KEY_ENABLED = "service_enabled"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAction(context: Context, gesture: NotchGesture): NotchAction {
        val name = prefs(context).getString("action_${gesture.name}", null) ?: defaultFor(gesture).name
        return try { NotchAction.valueOf(name) } catch (e: Exception) { NotchAction.NONE }
    }

    fun setAction(context: Context, gesture: NotchGesture, action: NotchAction) {
        prefs(context).edit().putString("action_${gesture.name}", action.name).apply()
    }

    private fun defaultFor(gesture: NotchGesture): NotchAction = when (gesture) {
        NotchGesture.SINGLE_TAP -> NotchAction.SCREENSHOT
        NotchGesture.DOUBLE_TAP -> NotchAction.TORCH_TOGGLE
        NotchGesture.LONG_PRESS -> NotchAction.LOCK_SCREEN
        NotchGesture.SWIPE_LEFT -> NotchAction.BACK
        NotchGesture.SWIPE_RIGHT -> NotchAction.RECENTS
    }

    fun getWidthDp(context: Context): Int = prefs(context).getInt(KEY_WIDTH, 120)
    fun setWidthDp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_WIDTH, v).apply()

    fun getHeightDp(context: Context): Int = prefs(context).getInt(KEY_HEIGHT, 60)
    fun setHeightDp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_HEIGHT, v).apply()

    // absolute position in dp from the top-left corner of the screen.
    // Not set until the user drags the zone (or it's auto-centered on first run).
    fun getOffsetXDp(context: Context): Int = prefs(context).getInt(KEY_OFFSET_X, 0)
    fun setOffsetXDp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_OFFSET_X, v).apply()

    fun getOffsetYDp(context: Context): Int = prefs(context).getInt(KEY_OFFSET_Y, 0)
    fun setOffsetYDp(context: Context, v: Int) = prefs(context).edit().putInt(KEY_OFFSET_Y, v).apply()

    fun isPositionSet(context: Context): Boolean = prefs(context).getBoolean(KEY_POSITION_SET, false)
    fun markPositionSet(context: Context) = prefs(context).edit().putBoolean(KEY_POSITION_SET, true).apply()

    fun setPosition(context: Context, xDp: Int, yDp: Int) {
        prefs(context).edit()
            .putInt(KEY_OFFSET_X, xDp)
            .putInt(KEY_OFFSET_Y, yDp)
            .putBoolean(KEY_POSITION_SET, true)
            .apply()
    }

    // when true, the zone becomes visible (bordered) and draggable instead of
    // acting as an invisible gesture button
    fun isEditMode(context: Context): Boolean = prefs(context).getBoolean(KEY_EDIT_MODE, false)
    fun setEditMode(context: Context, v: Boolean) = prefs(context).edit().putBoolean(KEY_EDIT_MODE, v).apply()

    fun getOpenAppPackage(context: Context): String? = prefs(context).getString(KEY_APP_PACKAGE, null)
    fun setOpenAppPackage(context: Context, pkg: String) =
        prefs(context).edit().putString(KEY_APP_PACKAGE, pkg).apply()

    fun isEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_ENABLED, true)
    fun setEnabled(context: Context, v: Boolean) = prefs(context).edit().putBoolean(KEY_ENABLED, v).apply()
}
