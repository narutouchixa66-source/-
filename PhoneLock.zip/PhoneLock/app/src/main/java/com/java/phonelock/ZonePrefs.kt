package com.java.phonelock

import android.content.Context
import android.content.SharedPreferences

object ZonePrefs {
    private const val PREFS_NAME = "phonelock_zone_prefs"

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getWidthDp(context: Context): Int = prefs(context).getInt("width_dp", 120)
    fun setWidthDp(context: Context, v: Int) = prefs(context).edit().putInt("width_dp", v).apply()

    fun getHeightDp(context: Context): Int = prefs(context).getInt("height_dp", 120)
    fun setHeightDp(context: Context, v: Int) = prefs(context).edit().putInt("height_dp", v).apply()

    // offset from top-left corner of the screen, in dp
    fun getOffsetXDp(context: Context): Int = prefs(context).getInt("offset_x_dp", 0)
    fun setOffsetXDp(context: Context, v: Int) = prefs(context).edit().putInt("offset_x_dp", v).apply()

    fun getOffsetYDp(context: Context): Int = prefs(context).getInt("offset_y_dp", 0)
    fun setOffsetYDp(context: Context, v: Int) = prefs(context).edit().putInt("offset_y_dp", v).apply()

    // 0 = top-left anchored, 1 = centered horizontally
    fun getCentered(context: Context): Boolean = prefs(context).getBoolean("centered", true)
    fun setCentered(context: Context, v: Boolean) = prefs(context).edit().putBoolean("centered", v).apply()
}
