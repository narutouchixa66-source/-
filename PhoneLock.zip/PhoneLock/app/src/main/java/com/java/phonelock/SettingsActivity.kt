package com.java.phonelock

import android.os.Bundle
import android.widget.CheckBox
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val seekWidth = findViewById<SeekBar>(R.id.seekWidth)
        val seekHeight = findViewById<SeekBar>(R.id.seekHeight)
        val seekX = findViewById<SeekBar>(R.id.seekX)
        val seekY = findViewById<SeekBar>(R.id.seekY)
        val checkCentered = findViewById<CheckBox>(R.id.checkCentered)

        seekWidth.progress = ZonePrefs.getWidthDp(this)
        seekHeight.progress = ZonePrefs.getHeightDp(this)
        seekX.progress = ZonePrefs.getOffsetXDp(this)
        seekY.progress = ZonePrefs.getOffsetYDp(this)
        checkCentered.isChecked = ZonePrefs.getCentered(this)

        seekWidth.setOnSeekBarChangeListener(simpleSeek { ZonePrefs.setWidthDp(this, it.coerceAtLeast(30)) })
        seekHeight.setOnSeekBarChangeListener(simpleSeek { ZonePrefs.setHeightDp(this, it.coerceAtLeast(30)) })
        seekX.setOnSeekBarChangeListener(simpleSeek { ZonePrefs.setOffsetXDp(this, it) })
        seekY.setOnSeekBarChangeListener(simpleSeek { ZonePrefs.setOffsetYDp(this, it) })
        checkCentered.setOnCheckedChangeListener { _, checked -> ZonePrefs.setCentered(this, checked) }
    }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }
}
