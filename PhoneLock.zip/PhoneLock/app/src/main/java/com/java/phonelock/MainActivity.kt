package com.java.phonelock

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.abs

private enum class ScreenState { LOCKED, RECOVERY, BOOTING }

class MainActivity : Activity() {

    private lateinit var flickerOverlay: View
    private lateinit var recoveryLayout: View
    private lateinit var recoveryListContainer: LinearLayout
    private lateinit var dwellBar: ProgressBar
    private lateinit var bootSpinner: ProgressBar

    private val handler = Handler(Looper.getMainLooper())
    private var state = ScreenState.LOCKED

    // ---- flicker ----
    private var flickerOn = false
    private val flickerRunnable = object : Runnable {
        override fun run() {
            if (state == ScreenState.LOCKED) {
                flickerOn = !flickerOn
                flickerOverlay.visibility = if (flickerOn) View.VISIBLE else View.GONE
            }
            handler.postDelayed(this, 2500)
        }
    }

    // ---- tap counting (no visible indicator) ----
    private val TAPS_NEEDED = 10
    private val TAP_WINDOW_MS = 1600L
    private val MOVE_TOLERANCE = 40f
    private var tapCount = 0
    private var lastTapTime = 0L
    private var downX = 0f
    private var downY = 0f
    private val tapResetRunnable = Runnable { tapCount = 0 }

    // ---- long press to open recovery ----
    private var longPressFired = false
    private val longPressRunnable = Runnable {
        longPressFired = true
        if (state == ScreenState.LOCKED) openRecovery()
    }
    private val LONG_PRESS_MS = 1500L

    // ---- recovery menu ----
    private val recoveryOptions = listOf(
        "Reboot system now",
        "Reboot to recovery mode",
        "Reboot to bootloader",
        "Power off"
    )
    private var recIndex = 0
    private lateinit var recoveryRows: List<TextView>
    private val DWELL_MS = 1800L
    private var dwellStartTime = 0L
    private val dwellTick = object : Runnable {
        override fun run() {
            if (state != ScreenState.RECOVERY) return
            val elapsed = System.currentTimeMillis() - dwellStartTime
            val pct = ((elapsed.toFloat() / DWELL_MS) * 100).toInt().coerceIn(0, 100)
            dwellBar.progress = pct
            if (elapsed >= DWELL_MS) {
                confirmRecoverySelection()
            } else {
                handler.postDelayed(this, 50)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        flickerOverlay = findViewById(R.id.flickerOverlay)
        recoveryLayout = findViewById(R.id.recoveryLayout)
        recoveryListContainer = findViewById(R.id.recoveryList)
        dwellBar = findViewById(R.id.dwellBar)
        bootSpinner = findViewById(R.id.bootSpinner)

        buildRecoveryRows()
        handler.postDelayed(flickerRunnable, 2500)

        // attempt screen pinning so Home/Recents are also blocked
        // (system will show a one-time confirmation the first time; this is an OS-level requirement, not skippable)
        try { startLockTask() } catch (e: Exception) { /* ignore if unsupported */ }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // intentionally blocked — do nothing
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    // ---------------- touch handling ----------------
    // Everything routes through here: in LOCKED state, taps are silently counted
    // (no visible counter, per requirement) and swipes/other gestures do nothing.
    // In RECOVERY state, touches do nothing at all except the long-press-to-close
    // safety valve for testing.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                longPressFired = false
                handler.postDelayed(longPressRunnable, LONG_PRESS_MS)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(ev.x - downX) > MOVE_TOLERANCE || abs(ev.y - downY) > MOVE_TOLERANCE) {
                    handler.removeCallbacks(longPressRunnable)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (!longPressFired) {
                    val dx = abs(ev.x - downX); val dy = abs(ev.y - downY)
                    val isTap = dx < MOVE_TOLERANCE && dy < MOVE_TOLERANCE
                    if (state == ScreenState.LOCKED) {
                        if (isTap) registerLockTap() else resetTapCount()
                    }
                    // RECOVERY / BOOTING: taps do nothing, by design
                }
            }
        }
        return true // consume everything — nothing passes through to the UI beneath
    }

    private fun registerLockTap() {
        val now = System.currentTimeMillis()
        if (now - lastTapTime > TAP_WINDOW_MS) tapCount = 0
        lastTapTime = now
        tapCount++
        handler.removeCallbacks(tapResetRunnable)
        handler.postDelayed(tapResetRunnable, TAP_WINDOW_MS)
        vibrate(8)
        if (tapCount >= TAPS_NEEDED) unlockDevice()
    }

    private fun resetTapCount() {
        tapCount = 0
        handler.removeCallbacks(tapResetRunnable)
    }

    private fun unlockDevice() {
        handler.removeCallbacks(flickerRunnable)
        flickerOverlay.visibility = View.GONE
        vibrate(20)
        try { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) stopLockTask() } catch (e: Exception) {}
        finish() // releases the lock — phone returns to whatever was open before
    }

    // ---------------- volume keys ----------------
    // In LOCKED state: fully blocked, nothing happens (as requested).
    // In RECOVERY state: real hardware interception — moves the selection and
    // consumes the event so system volume never actually changes.
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (state) {
                ScreenState.LOCKED -> return true // swallow, do nothing
                ScreenState.RECOVERY -> {
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) moveRecovery(-1) else moveRecovery(1)
                    return true
                }
                ScreenState.BOOTING -> return true
            }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) return true
        return super.onKeyDown(keyCode, event)
    }

    // ---------------- recovery menu ----------------
    private fun buildRecoveryRows() {
        recoveryListContainer.removeAllViews()
        recoveryRows = recoveryOptions.map { label ->
            TextView(this).apply {
                text = "  $label"
                setTextColor(Color.parseColor("#9FAE9F"))
                textSize = 14f
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(24, 20, 24, 20)
                alpha = 0.7f
            }
        }
        recoveryRows.forEach { recoveryListContainer.addView(it) }
    }

    private fun renderRecoverySelection() {
        recoveryRows.forEachIndexed { i, tv ->
            val active = i == recIndex
            tv.text = (if (active) "> " else "  ") + recoveryOptions[i]
            tv.setTextColor(Color.parseColor(if (active) "#E9FFE9" else "#9FAE9F"))
            tv.alpha = if (active) 1f else 0.7f
        }
    }

    private fun openRecovery() {
        state = ScreenState.RECOVERY
        recIndex = 0
        renderRecoverySelection()
        flickerOverlay.visibility = View.GONE
        recoveryLayout.visibility = View.VISIBLE
        bootSpinner.visibility = View.GONE
        startDwell()
    }

    private fun moveRecovery(dir: Int) {
        recIndex = (recIndex + dir + recoveryOptions.size) % recoveryOptions.size
        renderRecoverySelection()
        vibrate(6)
        startDwell()
    }

    private fun startDwell() {
        dwellStartTime = System.currentTimeMillis()
        dwellBar.progress = 0
        handler.removeCallbacks(dwellTick)
        handler.postDelayed(dwellTick, 50)
    }

    private fun confirmRecoverySelection() {
        state = ScreenState.BOOTING
        dwellBar.visibility = View.GONE
        bootSpinner.visibility = View.VISIBLE
        vibrate(15)
        handler.postDelayed({
            // "reboot" — loop back to the locked photo screen
            bootSpinner.visibility = View.GONE
            dwellBar.visibility = View.VISIBLE
            recoveryLayout.visibility = View.GONE
            state = ScreenState.LOCKED
            handler.post(flickerRunnable)
        }, 2600)
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
