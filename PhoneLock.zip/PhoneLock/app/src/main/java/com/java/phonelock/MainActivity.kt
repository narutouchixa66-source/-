package com.java.phonelock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import kotlin.math.abs

/** App states. IDLE = waiting for a gesture on the trigger zone. */
private enum class ScreenState { IDLE, LOCKED, RECOVERY, BOOTING }

class MainActivity : Activity() {

    private lateinit var triggerZone: View
    private lateinit var idleBg: View
    private lateinit var lockImage: View
    private lateinit var flickerOverlay: View
    private lateinit var recoveryLayout: View
    private lateinit var recoveryListContainer: LinearLayout
    private lateinit var dwellBar: ProgressBar
    private lateinit var bootSpinner: ProgressBar

    private val handler = Handler(Looper.getMainLooper())
    private var state = ScreenState.IDLE

    // ---- flicker (only while LOCKED) ----
    private var flickerOn = false
    private val flickerRunnable = object : Runnable {
        override fun run() {
            if (state == ScreenState.LOCKED) {
                flickerOn = !flickerOn
                flickerOverlay.visibility = if (flickerOn) View.VISIBLE else View.GONE
            }
            handler.postDelayed(this, 2500)
        }
    }

    // ---- auto-unlock safety timeout: if still LOCKED after 10 minutes, release on its own ----
    private val AUTO_UNLOCK_MS = 10 * 60 * 1000L
    private val autoUnlockRunnable = Runnable {
        if (state == ScreenState.LOCKED) unlockDevice()
    }

    // ---- unlock from LOCKED: 10x volume-up in a row, no visible counter ----
    private val VOLUME_TAPS_NEEDED = 10
    private val VOLUME_WINDOW_MS = 1800L
    private var volumeUpCount = 0
    private var lastVolumeTime = 0L
    private val volumeResetRunnable = Runnable { volumeUpCount = 0 }

    // ---- trigger zone gesture (single tap / double tap), only while IDLE ----
    private var zoneDownTime = 0L
    private var zoneDownX = 0f
    private var zoneDownY = 0f
    private var lastZoneTapTime = 0L
    private val MOVE_TOLERANCE = 40f
    private val DOUBLE_TAP_WINDOW_MS = 320L
    private var pendingSingleTap: Runnable? = null

    // ---- recovery menu ----
    private val recoveryOptions = listOf(
        "Reboot system now",
        "Reboot to recovery mode",
        "Reboot to bootloader",
        "Power off"
    )
    private var recIndex = 0
    private lateinit var recoveryRows: List<TextView>
    private val DWELL_MS = 1800L
    private var dwellStartTime = 0L
    private val dwellTick = object : Runnable {
        override fun run() {
            if (state != ScreenState.RECOVERY) return
            val elapsed = System.currentTimeMillis() - dwellStartTime
            val pct = ((elapsed.toFloat() / DWELL_MS) * 100).toInt().coerceIn(0, 100)
            dwellBar.progress = pct
            if (elapsed >= DWELL_MS) {
                confirmRecoverySelection()
            } else {
                handler.postDelayed(this, 50)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUI()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        idleBg = findViewById(R.id.idleBg)
        triggerZone = findViewById(R.id.triggerZone)
        lockImage = findViewById(R.id.lockImage)
        flickerOverlay = findViewById(R.id.flickerOverlay)
        recoveryLayout = findViewById(R.id.recoveryLayout)
        recoveryListContainer = findViewById(R.id.recoveryList)
        dwellBar = findViewById(R.id.dwellBar)
        bootSpinner = findViewById(R.id.bootSpinner)

        buildRecoveryRows()
        applyZoneGeometry()
        setupZoneTouch()
    }

    override fun onResume() {
        super.onResume()
        applyZoneGeometry() // pick up any change made in Settings
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // intentionally blocked in every state except IDLE (where blocking
        // back would trap the user with no way out before they've even
        // triggered the prank)
        if (state == ScreenState.IDLE) super.onBackPressed()
    }

    // Full-screen touch gate: while LOCKED/RECOVERY/BOOTING, absolutely
    // nothing on screen reacts to touch — everything is swallowed here
    // before it ever reaches a child view. Only while IDLE do touches pass
    // through normally so the trigger zone's own listener can work.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (state != ScreenState.IDLE) {
            hideSystemUI()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()

    private fun applyZoneGeometry() {
        val lp = triggerZone.layoutParams as FrameLayout.LayoutParams
        lp.width = dpToPx(ZonePrefs.getWidthDp(this))
        lp.height = dpToPx(ZonePrefs.getHeightDp(this))
        if (ZonePrefs.getCentered(this)) {
            lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            lp.leftMargin = 0
        } else {
            lp.gravity = Gravity.TOP or Gravity.START
            lp.leftMargin = dpToPx(ZonePrefs.getOffsetXDp(this))
        }
        lp.topMargin = dpToPx(ZonePrefs.getOffsetYDp(this))
        triggerZone.layoutParams = lp
    }

    // ---------------- trigger zone: single tap = lock, double tap = recovery ----------------
    private fun setupZoneTouch() {
        triggerZone.setOnTouchListener { _, ev ->
            if (state != ScreenState.IDLE) return@setOnTouchListener true
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    zoneDownTime = System.currentTimeMillis()
                    zoneDownX = ev.rawX; zoneDownY = ev.rawY
                }
                MotionEvent.ACTION_UP -> {
                    val dx = abs(ev.rawX - zoneDownX); val dy = abs(ev.rawY - zoneDownY)
                    if (dx < MOVE_TOLERANCE && dy < MOVE_TOLERANCE) {
                        val now = System.currentTimeMillis()
                        if (now - lastZoneTapTime < DOUBLE_TAP_WINDOW_MS) {
                            // double tap -> recovery, cancel the pending single-tap action
                            pendingSingleTap?.let { handler.removeCallbacks(it) }
                            lastZoneTapTime = 0
                            enterRecovery()
                        } else {
                            lastZoneTapTime = now
                            val action = Runnable {
                                if (lastZoneTapTime != 0L) enterLocked()
                            }
                            pendingSingleTap = action
                            handler.postDelayed(action, DOUBLE_TAP_WINDOW_MS)
                        }
                    }
                }
            }
            true
        }
    }

    private fun enterLocked() {
        state = ScreenState.LOCKED
        idleBg.visibility = View.GONE
        lockImage.visibility = View.VISIBLE
        recoveryLayout.visibility = View.GONE
        volumeUpCount = 0
        handler.post(flickerRunnable)
        handler.removeCallbacks(autoUnlockRunnable)
        handler.postDelayed(autoUnlockRunnable, AUTO_UNLOCK_MS)
    }

    // ---------------- volume keys ----------------
    // LOCKED: 10x volume-up in a row unlocks (silently, no counter shown);
    //         volume-down resets the streak; both are fully swallowed either way.
    // RECOVERY: real hardware interception moves the selection; system volume
    //           never actually changes because we consume the event.
    // IDLE: volume behaves normally (not intercepted).
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            when (state) {
                ScreenState.LOCKED -> {
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
                        val now = System.currentTimeMillis()
                        if (now - lastVolumeTime > VOLUME_WINDOW_MS) volumeUpCount = 0
                        lastVolumeTime = now
                        volumeUpCount++
                        handler.removeCallbacks(volumeResetRunnable)
                        handler.postDelayed(volumeResetRunnable, VOLUME_WINDOW_MS)
                        vibrate(8)
                        if (volumeUpCount >= VOLUME_TAPS_NEEDED) unlockDevice()
                    } else {
                        volumeUpCount = 0
                    }
                    return true
                }
                ScreenState.RECOVERY -> {
                    if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) moveRecovery(-1) else moveRecovery(1)
                    return true
                }
                ScreenState.BOOTING -> return true
                ScreenState.IDLE -> return super.onKeyDown(keyCode, event)
            }
        }
        if (state != ScreenState.IDLE && (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME)) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun unlockDevice() {
        handler.removeCallbacks(flickerRunnable)
        handler.removeCallbacks(autoUnlockRunnable)
        flickerOverlay.visibility = View.GONE
        lockImage.visibility = View.GONE
        idleBg.visibility = View.VISIBLE
        vibrate(20)
        state = ScreenState.IDLE
    }

    // ---------------- recovery menu ----------------
    private fun buildRecoveryRows() {
        recoveryListContainer.removeAllViews()
        recoveryRows = recoveryOptions.map { label ->
            TextView(this).apply {
                text = "  $label"
                setTextColor(Color.parseColor("#9FAE9F"))
                textSize = 14f
                typeface = android.graphics.Typeface.MONOSPACE
                setPadding(24, 20, 24, 20)
                alpha = 0.7f
            }
        }
        recoveryRows.forEach { recoveryListContainer.addView(it) }
    }

    private fun renderRecoverySelection() {
        recoveryRows.forEachIndexed { i, tv ->
            val active = i == recIndex
            tv.text = (if (active) "> " else "  ") + recoveryOptions[i]
            tv.setTextColor(Color.parseColor(if (active) "#E9FFE9" else "#9FAE9F"))
            tv.alpha = if (active) 1f else 0.7f
        }
    }

    private fun enterRecovery() {
        state = ScreenState.RECOVERY
        recIndex = 0
        renderRecoverySelection()
        idleBg.visibility = View.GONE
        lockImage.visibility = View.GONE
        flickerOverlay.visibility = View.GONE
        recoveryLayout.visibility = View.VISIBLE
        dwellBar.visibility = View.VISIBLE
        bootSpinner.visibility = View.GONE
        startDwell()
    }

    private fun moveRecovery(dir: Int) {
        recIndex = (recIndex + dir + recoveryOptions.size) % recoveryOptions.size
        renderRecoverySelection()
        vibrate(6)
        startDwell()
    }

    private fun startDwell() {
        dwellStartTime = System.currentTimeMillis()
        dwellBar.progress = 0
        handler.removeCallbacks(dwellTick)
        handler.postDelayed(dwellTick, 50)
    }

    private fun confirmRecoverySelection() {
        state = ScreenState.BOOTING
        dwellBar.visibility = View.GONE
        bootSpinner.visibility = View.VISIBLE
        vibrate(15)
        handler.postDelayed({
            // "reboot" -> loop back to the locked photo screen
            bootSpinner.visibility = View.GONE
            recoveryLayout.visibility = View.GONE
            enterLocked()
        }, 2600)
    }

    private fun vibrate(ms: Long) {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) {
            // never let a missing vibrator permission/service crash the app
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
